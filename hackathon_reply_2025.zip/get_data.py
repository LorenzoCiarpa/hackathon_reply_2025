from read_file import read_input_file
from sorter import sort_resources, sort_by_efficiency, compute_efficiency


def get_data(file_path = "./data/0-demo.txt"):
    # Esempio di utilizzo
    
    return